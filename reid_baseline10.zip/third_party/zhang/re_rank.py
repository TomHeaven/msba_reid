# author = xy
# encoding = utf-8


import numpy as np
import torch
from data_pre import data_prefetcher
from tqdm import tqdm
import json
import eval_helper
from local_infer_helper import low_memory_local_dist
import torch.nn.functional as F
import tqdm


def mem_saving_argsort(a, top_k=10):
    assert a.ndim==2
    top_k = min(a.shape[1], top_k)
    idx = np.zeros((a.shape[0],top_k), dtype=np.int32)
    for i in tqdm.tqdm(range(len(a))):
        idx[i] = np.argsort(a[i])[:top_k]
    return idx


def mem_saving_divide(a, b):
    for i in range(len(a)):
        a[i] = a[i] / b
    return a


def re_ranking(probFea, galFea, k1, k2, lambda_value, local_distmat=None, theta_value=0.5, only_local=False,
               MemorySave=True, Minibatch = 5000):
    # if feature vector is numpy, you should use 'torch.tensor' transform it to tensor
    query_num = probFea.size(0)
    all_num = query_num + galFea.size(0)
    if only_local:
        original_dist = local_distmat
    else:
        print('Computing original distance using GPU ...')
        feat = torch.cat([probFea, galFea]).cuda()

        if MemorySave:
            distmat = torch.zeros((all_num, all_num), dtype=torch.float16) # 14 GB memory on Round2
            i = 0
            while True:
                it = i + Minibatch
                #print('i, it', i, it)
                if it < feat.size()[0]:
                    distmat[i:it, :] = torch.pow(torch.cdist(feat[i:it, :], feat), 2)
                else:
                    distmat[i:, :] = torch.pow(torch.cdist(feat[i:, :], feat), 2)
                    break
                i = it
        else:
            ### new API
            distmat = torch.pow(torch.cdist(feat, feat), 2)

        #print('Copy distmat to original_dist ...')
        original_dist = distmat.numpy() # fast
        del distmat
        del feat
        if not local_distmat is None:
            original_dist = original_dist * theta_value + local_distmat * (1 - theta_value)
    gallery_num = original_dist.shape[0]

    ### memory optimization
    print('Division ...')
    # memory inefficient
    #original_dist = np.transpose(original_dist / np.max(original_dist, axis=0))
    m = np.max(original_dist, axis=0)
    original_dist = mem_saving_divide(original_dist, m)
    #print('Transpose ...')
    original_dist = original_dist.T    # ultra fast
    ###
    print('Argsort to get initial_rank ...')
    #initial_rank = np.argsort(original_dist)  # .astype(np.int32)
    initial_rank = mem_saving_argsort(original_dist, top_k=k1+1)

    print('Allocate V ...')
    V = np.zeros_like(original_dist, dtype=np.float16)

    print('Start re_ranking ...')
    for i in tqdm.tqdm(range(all_num)):
        # k-reciprocal neighbors
        forward_k_neigh_index = initial_rank[i, :k1 + 1]
        backward_k_neigh_index = initial_rank[forward_k_neigh_index, :k1 + 1]
        fi = np.where(backward_k_neigh_index == i)[0]
        k_reciprocal_index = forward_k_neigh_index[fi]
        k_reciprocal_expansion_index = k_reciprocal_index
        for j in range(len(k_reciprocal_index)):
            candidate = k_reciprocal_index[j]
            candidate_forward_k_neigh_index = initial_rank[candidate, :int(np.around(k1 / 2)) + 1]
            candidate_backward_k_neigh_index = initial_rank[candidate_forward_k_neigh_index,
                                               :int(np.around(k1 / 2)) + 1]
            fi_candidate = np.where(candidate_backward_k_neigh_index == candidate)[0]
            candidate_k_reciprocal_index = candidate_forward_k_neigh_index[fi_candidate]
            if len(np.intersect1d(candidate_k_reciprocal_index, k_reciprocal_index)) > 2 / 3 * len(
                    candidate_k_reciprocal_index):
                k_reciprocal_expansion_index = np.append(k_reciprocal_expansion_index, candidate_k_reciprocal_index)

        k_reciprocal_expansion_index = np.unique(k_reciprocal_expansion_index)
        weight = np.exp(-original_dist[i, k_reciprocal_expansion_index])
        V[i, k_reciprocal_expansion_index] = weight / np.sum(weight)

    original_dist = original_dist[:query_num, :]
    if k2 != 1:
        V_qe = np.zeros_like(V, dtype=np.float16)
        for i in range(all_num):
            V_qe[i, :] = np.mean(V[initial_rank[i, :k2], :], axis=0)
        V = V_qe
        del V_qe
    del initial_rank
    invIndex = []
    for i in tqdm.tqdm(range(gallery_num)):
        invIndex.append(np.where(V[:, i] != 0)[0])

    ##### To save memory, don't allocate another matrix, re-use memory of original_dist instead
    #jaccard_dist = np.zeros_like(original_dist, dtype=np.float16)

    for i in tqdm.tqdm(range(query_num)):
        temp_min = np.zeros(shape=[1, gallery_num], dtype=np.float16)
        indNonZero = np.where(V[i, :] != 0)[0]
        indImages = [invIndex[ind] for ind in indNonZero]
        for j in range(len(indNonZero)):
            temp_min[0, indImages[j]] = temp_min[0, indImages[j]] + np.minimum(V[i, indNonZero[j]],
                                                                               V[indImages[j], indNonZero[j]])
        #######
        #jaccard_dist[i] = 1 - temp_min / (2 - temp_min)
        jaccard_dist_i = 1 - temp_min / (2 - temp_min)
        original_dist[i] = jaccard_dist_i * (1 - lambda_value) + original_dist[i] * lambda_value
        #######

    #final_dist = jaccard_dist * (1 - lambda_value) + original_dist * lambda_value
    #del original_dist
    del V
    #del jaccard_dist
    final_dist = original_dist[:query_num, query_num:]
    return final_dist


#
#
# def re_ranking(probFea, galFea, k1, k2, lambda_value, local_distmat=None, theta_value=0.5, only_local=False):
#     # if feature vector is numpy, you should use 'torch.tensor' transform it to tensor
#     query_num = probFea.size(0)
#     all_num = query_num + galFea.size(0)
#     if only_local:
#         original_dist = local_distmat
#     else:
#         feat = torch.cat([probFea,galFea])
#         #print('using GPU to compute original distance')
#
#         distmat = torch.pow(feat,2).sum(dim=1, keepdim=True).expand(all_num,all_num) + \
#                       torch.pow(feat, 2).sum(dim=1, keepdim=True).expand(all_num, all_num).t()
#         distmat.addmm_(1,-2,feat,feat.t())
#         original_dist = distmat.cpu().numpy()
#         del feat
#         if not local_distmat is None:
#             original_dist = original_dist * theta_value + local_distmat * (1 - theta_value)
#     gallery_num = original_dist.shape[0]
#     original_dist = np.transpose(original_dist / np.max(original_dist, axis=0))
#     V = np.zeros_like(original_dist).astype(np.float16)
#     initial_rank = np.argsort(original_dist).astype(np.int32)
#
#     #print('starting re_ranking')
#     for i in range(all_num):
#         # k-reciprocal neighbors
#         forward_k_neigh_index = initial_rank[i, :k1 + 1]
#         backward_k_neigh_index = initial_rank[forward_k_neigh_index, :k1 + 1]
#         fi = np.where(backward_k_neigh_index == i)[0]
#         k_reciprocal_index = forward_k_neigh_index[fi]
#         k_reciprocal_expansion_index = k_reciprocal_index
#         for j in range(len(k_reciprocal_index)):
#             candidate = k_reciprocal_index[j]
#             candidate_forward_k_neigh_index = initial_rank[candidate, :int(np.around(k1 / 2)) + 1]
#             candidate_backward_k_neigh_index = initial_rank[candidate_forward_k_neigh_index,
#                                                :int(np.around(k1 / 2)) + 1]
#             fi_candidate = np.where(candidate_backward_k_neigh_index == candidate)[0]
#             candidate_k_reciprocal_index = candidate_forward_k_neigh_index[fi_candidate]
#             if len(np.intersect1d(candidate_k_reciprocal_index, k_reciprocal_index)) > 2 / 3 * len(
#                     candidate_k_reciprocal_index):
#                 k_reciprocal_expansion_index = np.append(k_reciprocal_expansion_index, candidate_k_reciprocal_index)
#
#         k_reciprocal_expansion_index = np.unique(k_reciprocal_expansion_index)
#         weight = np.exp(-original_dist[i, k_reciprocal_expansion_index])
#         V[i, k_reciprocal_expansion_index] = weight / np.sum(weight)
#     original_dist = original_dist[:query_num, ]
#     if k2 != 1:
#         V_qe = np.zeros_like(V, dtype=np.float16)
#         for i in range(all_num):
#             V_qe[i, :] = np.mean(V[initial_rank[i, :k2], :], axis=0)
#         V = V_qe
#         del V_qe
#     del initial_rank
#     invIndex = []
#     for i in range(gallery_num):
#         invIndex.append(np.where(V[:, i] != 0)[0])
#
#     jaccard_dist = np.zeros_like(original_dist, dtype=np.float16)
#
#     for i in range(query_num):
#         temp_min = np.zeros(shape=[1, gallery_num], dtype=np.float16)
#         indNonZero = np.where(V[i, :] != 0)[0]
#         indImages = [invIndex[ind] for ind in indNonZero]
#         for j in range(len(indNonZero)):
#             temp_min[0, indImages[j]] = temp_min[0, indImages[j]] + np.minimum(V[i, indNonZero[j]],
#                                                                                V[indImages[j], indNonZero[j]])
#         jaccard_dist[i] = 1 - temp_min / (2 - temp_min)
#
#     final_dist = jaccard_dist * (1 - lambda_value) + original_dist * lambda_value
#     del original_dist
#     del V
#     del jaccard_dist
#     final_dist = final_dist[:query_num, query_num:]
#     return final_dist



def compute_metric_rerank(qf, gf, flip_qf, flip_gf, qf_ids, gf_ids, k1, k2, lambda_value, max_rank=200):

    distmat = re_ranking(qf, gf, k1, k2, lambda_value)
    distmat_flip = re_ranking(flip_qf, flip_gf, k1, k2, lambda_value)
    distmat = (distmat + distmat_flip) / 2

    indices = np.argsort(distmat, axis=1)
    matchs = (gf_ids[indices] == qf_ids[:, np.newaxis]).astype(np.int32)

    all_cmc = []
    all_ap = []
    num_valid = 0
    for i in range(len(matchs)):
        org_cmc = matchs[i]
        if sum(org_cmc) == 0:
            continue
        num_valid += 1

        cmc = org_cmc.cumsum()
        cmc[cmc > 1] = 1
        all_cmc.append(cmc[: max_rank])

        num_rel = org_cmc.sum()
        tmp_cmc = org_cmc.cumsum()
        tmp_cmc = [x / (i + 1.0) for i, x in enumerate(tmp_cmc)]
        tmp_cmc = np.asarray(tmp_cmc) * org_cmc
        ap = tmp_cmc.sum() / num_rel
        all_ap.append(ap)

    all_cmc = np.asarray(all_cmc).astype(np.float32)
    all_cmc = all_cmc.sum(0) / num_valid
    map_value = np.mean(all_ap)

    return all_cmc, map_value


def eval_model_rerank(model, val_dataloader, query_num, cfg):
    model.eval()
    feats = []
    flip_feats = []
    ids = []
    val_prefetcher = data_prefetcher(val_dataloader, cfg.input_mean, cfg.input_std)
    batch = val_prefetcher.next()
    while batch[0] is not None:
        with torch.no_grad():
            feat = model(batch)
            x = torch.flip(batch[0], [3])
            flip_feat = model([x, torch.Tensor([1])])

        feats.append(feat)
        flip_feats.append(flip_feat)
        ids.extend(batch[1].cpu().numpy())
        batch = val_prefetcher.next()

    feats = torch.cat(feats, dim=0)
    flip_feats = torch.cat(flip_feats, dim=0)
    if cfg.out_norm:
        feats = F.normalize(feats)
        flip_feats = F.normalize(flip_feats)

    qf = feats[: query_num]
    gf = feats[query_num:]

    flip_qf = flip_feats[: query_num]
    flip_gf = flip_feats[query_num:]

    qf_ids = np.asarray(ids[: query_num])
    gf_ids = np.asarray(ids[query_num:])

    if cfg.find_rerank_param:
        best_cmc = -999
        best_map = -999
        best_result = -999
        best_k1 = -9
        best_k2 = -9
        best_lambda_value = -9
        for k1 in tqdm(cfg.k1s):
            for k2 in cfg.k2s:
                for lambda_value in cfg.lambda_values:
                    cmc, Map = compute_metric_rerank(qf, gf, qf_ids, gf_ids, k1, k2, lambda_value)
                    result = (cmc[0] + Map) / 2
                    if result > best_result:
                        best_cmc = cmc
                        best_map = Map
                        best_result = result
                        best_k1 = k1
                        best_k2 = k2
                        best_lambda_value = lambda_value
                    print('k1:%d, k2:%d, lambda_value:%.2f, r1:%.4f, map:%.4f, result:%.4f' %
                          (k1, k2, lambda_value, cmc[0], Map, result))
        print('best, k1:%d, k2:%d, lambda_value:%.2f, r1:%.4f, map:%.4f, result:%.4f' %
              (best_k1, best_k2, best_lambda_value, best_cmc[0], best_map, best_result))

        return best_cmc, best_map
    else:
        cmc, Map = compute_metric_rerank(qf, gf, flip_qf, flip_gf, qf_ids, gf_ids, cfg.best_k1, cfg.best_k2, cfg.best_lambda_value)
        return cmc, Map


def test_single_model_rerank(model, test_dataloader, num_query, files, cfg):
    model.eval()
    feats = []
    flip_feats = []
    test_prefetcher = data_prefetcher(test_dataloader, cfg.input_mean, cfg.input_std)
    batch = test_prefetcher.next()
    while batch[0] is not None:
        with torch.no_grad():
            feat = model(batch)
            x = torch.flip(batch[0], [3])
            flip_feat = model([x, torch.Tensor([1])])

        feats.append(feat)
        flip_feats.append(flip_feat)
        batch = test_prefetcher.next()

    feats = torch.cat(feats, dim=0)
    flip_feats = torch.cat(flip_feats, dim=0)
    if cfg.out_norm:
        feats = F.normalize(feats)
        flip_feats = F.normalize(flip_feats)

    query_feats = feats[: num_query]
    query_flip_feats = flip_feats[: num_query]
    gallery_feats = feats[num_query:]
    gallery_flip_feats = flip_feats[num_query:]

    query_files = files[: num_query]
    gallery_files = files[num_query:]

    distmat = re_ranking(query_feats, gallery_feats, cfg.best_k1, cfg.best_k2, cfg.best_lambda_value)
    distmat_flip = re_ranking(query_flip_feats, gallery_flip_feats, cfg.best_k1, cfg.best_k2, cfg.best_lambda_value)
    distmat = (distmat + distmat_flip) / 2

    indices = np.argsort(distmat, axis=1)[:, :200]

    result_dict = dict()
    for q_idx in range(num_query):
        query_file = query_files[q_idx]
        gallery_file = [gallery_files[i] for i in indices[q_idx]]
        result_dict[query_file] = gallery_file
        # if q_idx < 10:
        #     print(query_file)
        #     print(gallery_file[:10])
        #     print()

    with open(cfg.submit_file, 'w', encoding='utf-8') as file:
        json.dump(result_dict, file)

    print('data_len:%d' % len(result_dict))


def test_single_model_rerank_local(model, test_dataloader, num_query, files, cfg):
    model.eval()
    global_feats = []
    local_feats = []
    flip_global_feats = []
    flip_local_feats = []
    test_prefetcher = data_prefetcher(test_dataloader, cfg.input_mean, cfg.input_std)
    batch = test_prefetcher.next()
    while batch[0] is not None:
        with torch.no_grad():
            global_feat, local_feat = model(batch)
            x = torch.flip(batch[0], [3])
            flip_global_feat, flip_local_feat = model([x, torch.Tensor([1])])

        global_feats.append(global_feat.data.cpu())
        local_feats.append(local_feat.data.cpu())
        flip_global_feats.append(flip_global_feat.data.cpu())
        flip_local_feats.append(flip_local_feat.data.cpu())
        batch = test_prefetcher.next()

    global_feats = torch.cat(global_feats, dim=0)
    local_feats = torch.cat(local_feats, dim=0)
    flip_global_feats = torch.cat(flip_global_feats, dim=0)
    flip_local_feats = torch.cat(flip_local_feats, dim=0)
    if cfg.out_norm:
        global_feats = F.normalize(global_feats)
        flip_global_feats = F.normalize(flip_global_feats)

    # files
    query_files = files[: num_query]
    gallery_files = files[num_query:]

    # query
    query_global_feats = global_feats[: num_query]
    query_local_feats = local_feats[: num_query]
    query_flip_global_feats = flip_global_feats[: num_query]
    query_flip_local_feats = flip_local_feats[: num_query]

    # gallery
    gallery_global_feats = global_feats[num_query:]
    gallery_local_feats = local_feats[num_query:]
    gallery_flip_global_feats = flip_global_feats[num_query:]
    gallery_flip_local_feats = flip_local_feats[num_query:]

    # 正推
    query_local_feats = query_local_feats.permute(0, 2, 1)
    gallery_local_feats = gallery_local_feats.permute(0, 2, 1)
    local_distmat = low_memory_local_dist(query_local_feats.numpy(), gallery_local_feats.numpy())
    local_qq_distmat = low_memory_local_dist(query_local_feats.numpy(), query_local_feats.numpy())
    local_gg_distmat = low_memory_local_dist(gallery_local_feats.numpy(), gallery_local_feats.numpy())
    local_dist = np.concatenate(
            [np.concatenate([local_qq_distmat, local_distmat], axis=1),
             np.concatenate([local_distmat.T, local_gg_distmat], axis=1)],
            axis=0)
    distmat = re_ranking(query_global_feats, gallery_global_feats, k1=cfg.best_k1, k2=cfg.best_k2,
                         lambda_value=cfg.best_lambda_value, local_distmat=local_dist, theta_value=cfg.theta, only_local=False)

    # flip推
    query_flip_local_feats = query_flip_local_feats.permute(0, 2, 1)
    gallery_flip_local_feats = gallery_flip_local_feats.permute(0, 2, 1)
    local_distmat = low_memory_local_dist(query_flip_local_feats.numpy(), gallery_flip_local_feats.numpy())
    local_qq_distmat = low_memory_local_dist(query_flip_local_feats.numpy(), query_flip_local_feats.numpy())
    local_gg_distmat = low_memory_local_dist(gallery_flip_local_feats.numpy(), gallery_flip_local_feats.numpy())
    local_dist = np.concatenate(
            [np.concatenate([local_qq_distmat, local_distmat], axis=1),
             np.concatenate([local_distmat.T, local_gg_distmat], axis=1)],
            axis=0)
    distmat_flip = re_ranking(query_flip_global_feats, gallery_flip_global_feats, k1=cfg.best_k1, k2=cfg.best_k2,
                              lambda_value=cfg.best_lambda_value, local_distmat=local_dist, theta_value=cfg.theta, only_local=False)

    distmat = (distmat + distmat_flip) / 2
    indices = np.argsort(distmat, axis=1)[:, :200]

    result_dict = dict()
    for q_idx in range(num_query):
        query_file = query_files[q_idx]
        gallery_file = [gallery_files[i] for i in indices[q_idx]]
        result_dict[query_file] = gallery_file
        # if q_idx < 10:
        #     print(query_file)
        #     print(gallery_file[:10])
        #     print()

    with open(cfg.submit_file, 'w', encoding='utf-8') as file:
        json.dump(result_dict, file)

    print('data_len:%d' % len(result_dict))
    return distmat





















