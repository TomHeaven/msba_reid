# author = xy
# encoding = utf-8

import torch
from helper import seed_everything
import os
import time
from data_pre import build_transform, ImageDatasetTrain, ImageDatasetVal, RandomIdentitySampler, fast_collate_fn
from data_pre import data_prefetcher
from optim_helpe import make_optimizer, make_lr_scheduler
from torch.utils.data import DataLoader
from eval_helper import eval_model
from models.baseline import Baseline
from config import Config as cfg


def train_blend(cfg):

    seed_everything(seed=333)

    # 载入数据
    train_file = cfg.train_data
    val_file = cfg.val_data

    train_transform = build_transform(cfg, is_train=True)
    val_transform = build_transform(cfg, is_train=False)

    train_data = ImageDatasetTrain(train_file, path=cfg.train_path, transform=train_transform)
    val_data = ImageDatasetVal(val_file, path=cfg.train_path, transform=val_transform)

    train_data_sampler = RandomIdentitySampler(train_data.ids, cfg.batch_size, cfg.num_instance)
    train_loader = DataLoader(train_data, cfg.batch_size, shuffle=False, num_workers=cfg.num_workers,
                              sampler=train_data_sampler, collate_fn=fast_collate_fn, pin_memory=True)

    val_loader = DataLoader(val_data, cfg.batch_size, num_workers=cfg.num_workers, collate_fn=fast_collate_fn,
                            pin_memory=True)

    # 构建模型
    model = Baseline(pretain_name=cfg.pretain_name,
                     num_class=len(train_data.id2id),
                     last_stride=cfg.last_stride,
                     margin=cfg.margin,
                     model_path=cfg.pretain_path)
    model.cuda()
    model_param_num = 0
    for p in model.parameters():
        if p.requires_grad:
            model_param_num += p.nelement()
    print('version:%s, model_base:%s, param_num:%d, num_class:%d, read_data_time:%d' %
          (cfg.version, cfg.pretain_name, model_param_num, len(train_data.id2id), train_data.time))

    # opt
    optimizer = make_optimizer(cfg, model)
    lr_sched = make_lr_scheduler(cfg, optimizer)

    # 训练迭代
    best_result = -999
    best_epoch = -9
    time0 = time.time()
    for epoch in range(cfg.epochs):
        time1 = time.time()
        model.train()
        train_prefetcher = data_prefetcher(train_loader, cfg.input_mean, cfg.input_std)
        batch = train_prefetcher.next()
        train_loss = 0
        train_id_loss = 0
        train_triplet_loss = 0
        train_c = 0
        while batch[0] is not None:
            loss, loss_list = model(batch)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            train_loss += loss.item()
            train_id_loss += loss_list[0].item()
            train_triplet_loss += loss_list[1].item()
            train_c += 1

            batch = train_prefetcher.next()

        train_loss = train_loss / train_c
        train_id_loss = train_id_loss / train_c
        train_triplet_loss = train_triplet_loss / train_c
        time_epoch = time.time()-time1
        print('train, epoch:%d, loss:%.4f, id_loss:%.4f, triplet_loss:%.4f, lr:%.2e, '
              '%ds/epoch, use_time:%ds, leave_time:%dmin' %
              (epoch, train_loss, train_id_loss, train_triplet_loss, optimizer.param_groups[0]['lr'],
               time_epoch, time.time()-time0, int((cfg.epochs-1-epoch)*time_epoch/60)))

        lr_sched.step()

        # val
        if epoch % cfg.eval_perid == 0 or epoch == cfg.epochs-1:
            cmc, Map = eval_model(model, val_loader, val_data.query_num, cfg)
            print('eval_val, epoch:%d, eval_num:%d, map:%.4f, rank1:%.4f, rank5:%.4f, rank10:%.4f, result:%.4f\n' %
                  (epoch, val_data.query_num, Map, cmc[0], cmc[4], cmc[9], (Map+cmc[0])/2))

            result = (Map+cmc[0])/2
            if result > best_result:
                best_result = result
                best_epoch = epoch
                state_dict = model.state_dict()
                model_path = os.path.join('../models', cfg.version+'.pkl')
                torch.save(state_dict, model_path)

        torch.cuda.empty_cache()

    print('best_epoch:%d, best_result:%.4f' % (best_epoch, best_result))


if __name__ == '__main__':
    train_blend(cfg)














