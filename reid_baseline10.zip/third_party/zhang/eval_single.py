# author = xy
# encoding = utf-8

from data_pre import build_transform, ImageDatasetVal, fast_collate_fn
from torch.utils.data import DataLoader
from split_data import split_data
import os
import torch
from eval_helper import eval_model
from re_rank import eval_model_rerank
from models.baseline import Baseline
from config import Config as cfg


def eval_blend(cfg):
    val_file = cfg.val_data

    val_transform = build_transform(cfg, is_train=False)
    val_data = ImageDatasetVal(val_file, path=cfg.train_path, transform=val_transform)
    val_loader = DataLoader(val_data, cfg.batch_size, num_workers=cfg.num_workers, collate_fn=fast_collate_fn,
                            pin_memory=True)

    model = Baseline(pretain_name=cfg.pretain_name,
                     num_class=7946,
                     last_stride=cfg.last_stride,
                     margin=cfg.margin,
                     model_path=cfg.pretain_path)

    model_path = os.path.join('../models', cfg.version+'.pkl')
    state_dict = torch.load(model_path)
    model.load_state_dict(state_dict)
    model.cuda()
    model.eval()

    if cfg.re_rank:
        cmc, Map = eval_model_rerank(model, val_loader, val_data.query_num, cfg)
        if not cfg.find_rerank_param:
            print('eval_val, re-rank, limit_num:%d, eval_num:%d, map:%.4f, rank1:%.4f, rank5:%.4f, rank10:%.4f, '
                  'result:%.4f' % (cfg.limit_num, val_data.query_num, Map, cmc[0], cmc[4], cmc[9], (Map+cmc[0])/2))
    else:
        cmc, Map = eval_model(model, val_loader, val_data.query_num, cfg)
        print('eval_val, limit_num:%d, eval_num:%d, map:%.4f, rank1:%.4f, rank5:%.4f, rank10:%.4f, result:%.4f' %
              (cfg.limit_num, val_data.query_num, Map, cmc[0], cmc[4], cmc[9], (Map+cmc[0])/2))


if __name__ == '__main__':
    # limit_num
    if True:
        data_file = '../data/复赛训练集/train_list.txt'
        for limit_num in range(2, 7):
            cfg.limit_num = limit_num
            split_data(data_file, ith=0, k_folds=5, limit_num=limit_num)
            eval_blend(cfg)

    # re-rank
    if False:
        data_file = '../data/初赛训练集/train_list.txt'
        split_data(data_file, ith=0, k_folds=5, limit_num=cfg.limit_num)
        eval_blend(cfg)



