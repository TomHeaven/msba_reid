# author = xy
# encoding = utf-8

import torch
from helper import seed_everything
import os
import time
from data_pre import build_transform, ImageDatasetTrain, RandomIdentitySampler, fast_collate_fn
from data_pre import data_prefetcher
from optim_helpe import make_optimizer, make_lr_scheduler
from torch.utils.data import DataLoader
from models.baseline import Baseline
from config import Config as cfg


def train_blend_all(cfg):

    # seed_everything(seed=333)

    # 载入数据
    train_file = cfg.data_file
    train_transform = build_transform(cfg, is_train=True)
    train_data = ImageDatasetTrain(train_file, path=cfg.train_path, transform=train_transform, use_all=True)

    train_data_sampler = RandomIdentitySampler(train_data.ids, cfg.batch_size, cfg.num_instance)
    train_loader = DataLoader(train_data, cfg.batch_size, shuffle=False, num_workers=cfg.num_workers,
                              sampler=train_data_sampler, collate_fn=fast_collate_fn, pin_memory=True)

    # 构建模型
    model = Baseline(pretain_name=cfg.pretain_name,
                     num_class=len(train_data.id2id),
                     last_stride=cfg.last_stride,
                     margin=cfg.margin,
                     model_path=cfg.pretain_path)
    model.cuda()
    model_param_num = 0
    for p in model.parameters():
        if p.requires_grad:
            model_param_num += p.nelement()
    print('version:%s, model_base:%s, param_num:%d, num_class:%d, read_data_time:%d' %
          (cfg.version, cfg.pretain_name, model_param_num, len(train_data.id2id), train_data.time))

    # opt
    optimizer = make_optimizer(cfg, model)
    lr_sched = make_lr_scheduler(cfg, optimizer)

    # 训练迭代
    time0 = time.time()
    for epoch in range(cfg.epochs):
        time1 = time.time()
        model.train()
        train_prefetcher = data_prefetcher(train_loader)
        batch = train_prefetcher.next()
        all_loss = 0
        id_loss = 0
        global_triplet_loss = 0
        local_triplet_loss = 0
        train_c = 0
        while batch[0] is not None:
            loss, loss_list = model(batch)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            all_loss += loss.item()
            id_loss += loss_list[0].item()
            global_triplet_loss += loss_list[1].item()
            local_triplet_loss += loss_list[2].item()
            train_c += 1

            batch = train_prefetcher.next()

        all_loss = all_loss / train_c
        id_loss = id_loss / train_c
        global_triplet_loss = global_triplet_loss / train_c
        local_triplet_loss = local_triplet_loss / train_c

        state_dict = model.state_dict()
        model_path = os.path.join('../models', cfg.version+'.pkl')
        torch.save(state_dict, model_path)

        torch.cuda.empty_cache()
        time_epoch = time.time()-time1
        print('train, epoch:%d, loss:%.4f, id_loss:%.4f, global_triplet_loss:%.4f, local_triplet_loss:%.4f, lr:%.2e, '
              '%ds/epoch, use_time:%ds, leave_time:%dmin' %
              (epoch, all_loss, id_loss, global_triplet_loss, local_triplet_loss, optimizer.param_groups[0]['lr'],
               time_epoch, time.time()-time0, int((cfg.epochs-1-epoch)*time_epoch/60)))
        lr_sched.step()


if __name__ == '__main__':
    cfg.version = 'baseline_v12_5'
    train_blend_all(cfg)

    cfg.version = 'baseline_v12_6'
    train_blend_all(cfg)

    cfg.version = 'baseline_v12_7'
    train_blend_all(cfg)
















