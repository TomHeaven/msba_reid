# author = xy
# encoding = utf-8


import math
import random
import numpy as np
import os
from PIL import Image
import pickle
import copy
import time
from collections import defaultdict
import torch
import torchvision.transforms as T
from torch.utils.data import Dataset
from torch.utils.data.sampler import Sampler


class RandomErasing(object):
    """ Randomly selects a rectangle region in an image and erases its pixels.
        'Random Erasing Data Augmentation' by Zhong et al.
        See https://arxiv.org/pdf/1708.04896.pdf
    Args:
         probability: The probability that the Random Erasing operation will be performed.
         sl: Minimum proportion of erased area against input image.
         sh: Maximum proportion of erased area against input image.
         r1: Minimum aspect ratio of erased area.
         mean: Erasing value.
    """

    def __init__(self, probability=0.5, sl=0.02, sh=0.4, r1=0.3, mean=(255*0.59606, 255*0.55814, 255*0.49735)):
        self.probability = probability
        self.mean = mean
        self.sl = sl
        self.sh = sh
        self.r1 = r1

    def __call__(self, img):
        img = np.asarray(img, dtype=np.uint8).copy()
        if random.uniform(0, 1) > self.probability:
            return img

        for attempt in range(100):
            area = img.shape[0] * img.shape[1]

            target_area = random.uniform(self.sl, self.sh) * area
            aspect_ratio = random.uniform(self.r1, 1 / self.r1)

            h = int(round(math.sqrt(target_area * aspect_ratio)))
            w = int(round(math.sqrt(target_area / aspect_ratio)))

            if w < img.shape[1] and h < img.shape[0]:
                x1 = random.randint(0, img.shape[0] - h)
                y1 = random.randint(0, img.shape[1] - w)
                if img.shape[2] == 3:
                    img[x1:x1 + h, y1:y1 + w, 0] = self.mean[0]
                    img[x1:x1 + h, y1:y1 + w, 1] = self.mean[1]
                    img[x1:x1 + h, y1:y1 + w, 2] = self.mean[2]
                else:
                    img[x1:x1 + h, y1:y1 + w, 0] = self.mean[0]
                return img

        return img


def build_transform(cfg, is_train=True):
    res = []
    if is_train:
        res.append(T.Resize(cfg.input_size))
        if cfg.input_do_flip:
            res.append(T.RandomHorizontalFlip(p=cfg.input_flip_prob))
        if cfg.input_do_pad:
            res.extend([T.Pad(cfg.input_padding, padding_mode=cfg.input_padding_mode),
                        T.RandomCrop(cfg.input_size)])
        if cfg.input_do_lighting:
            res.append(T.ColorJitter(cfg.input_max_lighting, cfg.input_max_lighting))
        if cfg.input_do_re:
            res.append(RandomErasing(probability=cfg.input_re_prob))
    else:
        res.append(T.Resize(cfg.input_size))
    return T.Compose(res)


def read_image(img_path):
    """Keep reading image until succeed.
    This can avoid IOError incurred by heavy IO process."""
    got_img = False
    if not os.path.exists(img_path):
        raise IOError("{} does not exist".format(img_path))
    while not got_img:
        try:
            img = Image.open(img_path).convert('RGB')
            got_img = True
        except IOError:
            print("IOError incurred when reading '{}'. Will redo. Don't worry. Just chill.".format(img_path))
            pass
    return img


class ImageDatasetTrain(Dataset):
    def __init__(self, data_file, path, transform):
        with open(data_file, 'rb') as file:
            data_dict = pickle.load(file)
            imgs = data_dict['img']
            ids = data_dict['id']

        time0 = time.time()
        self.imgs = [read_image(os.path.join(path, file_path)) for file_path in imgs]
        self.time = time.time() - time0
        self.ids = ids
        self.id2id = dict([(id_i, i) for i, id_i in enumerate(set(ids))])
        self.transform = transform

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, item):
        img_item = self.imgs[item]

        img_item = self.transform(img_item)
        id_item = self.ids[item]
        id_item = self.id2id[id_item]

        return img_item, id_item


class ImageDatasetVal(Dataset):
    def __init__(self, data_file, path, transform):
        with open(data_file, 'rb') as file:
            data_dict = pickle.load(file)
            querys = data_dict['query']
            query_ids = data_dict['query_id']
            gallerys = data_dict['gallery']
            gallery_ids = data_dict['gallery_id']

        imgs = querys + gallerys
        ids = query_ids + gallery_ids

        self.query_num = len(querys)
        self.imgs = [read_image(os.path.join(path, file_path)) for file_path in imgs]
        self.ids = ids
        self.id2id = dict([(id_i, i) for i, id_i in enumerate(set(ids))])
        self.transform = transform

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, item):
        img_item = self.imgs[item]

        img_item = self.transform(img_item)
        id_item = self.ids[item]
        id_item = self.id2id[id_item]

        return img_item, id_item


class RandomIdentitySampler(Sampler):
    def __init__(self, ids, batch_size, num_instances):

        self.batch_size = batch_size
        self.num_instances = num_instances
        self.num_pid_per_batch = self.batch_size // self.num_instances
        self.index_dict = defaultdict(list)
        for index, id_i in enumerate(ids):
            self.index_dict[id_i].append(index)
        self.ids = list(self.index_dict.keys())

        self.length = 0
        for id_i in self.ids:
            idxs = self.index_dict[id_i]
            num = len(idxs)
            if num < self.num_instances:
                num = self.num_instances
            self.length += num - num % self.num_instances

    def __iter__(self):
        batch_idx_dict = defaultdict(list)

        num = 0
        for id_i in self.ids:
            idxs = copy.deepcopy(self.index_dict[id_i])
            if len(idxs) < self.num_instances:
                idxs = idxs + np.random.choice(idxs, size=self.num_instances-len(idxs), replace=True).tolist()
                # idxs = np.random.choice(idxs, size=self.num_instances, replace=True)
            random.shuffle(idxs)
            batch_idxs = []
            for idx in idxs:
                batch_idxs.append(idx)
                if len(batch_idxs) == self.num_instances:
                    batch_idx_dict[id_i].append(batch_idxs)
                    batch_idxs = []
            # num += 1
            # if num == 10:
            #     # print(batch_idx_dict)
            #     assert 1 == -1

        avai_ids = copy.deepcopy(self.ids)
        final_idxs = []

        while len(avai_ids) >= self.num_pid_per_batch:
            selected_ids = random.sample(avai_ids, self.num_pid_per_batch)
            for id_i in selected_ids:
                batch_idxs = batch_idx_dict[id_i].pop(0)
                final_idxs.extend(batch_idxs)
                if len(batch_idx_dict[id_i]) == 0:
                    avai_ids.remove(id_i)

        return iter(final_idxs)

    def __len__(self):
        return self.length


def fast_collate_fn(batch):
    imgs, ids = zip(*batch)
    is_ndarray = isinstance(imgs[0], np.ndarray)
    if not is_ndarray:
        w = imgs[0].size[0]
        h = imgs[0].size[1]
    else:
        w = imgs[0].shape[1]
        h = imgs[0].shape[0]
    tensor = torch.zeros((len(imgs), 3, h, w), dtype=torch.uint8)
    for i, img in enumerate(imgs):
        if not is_ndarray:
            img = np.asarray(img, dtype=np.uint8)
        numpy_array = np.rollaxis(img, 2)
        tensor[i] += torch.from_numpy(numpy_array)
    return tensor, torch.tensor(ids).long()


class data_prefetcher():
    def __init__(self, loader):
        self.loader = iter(loader)
        self.stream = torch.cuda.Stream()
        self.mean = torch.tensor([0.485*255, 0.456*255, 0.406*255]).cuda().view(1,3,1,1)
        self.std = torch.tensor([0.229*255, 0.224*255, 0.225*255]).cuda().view(1,3,1,1)
        # With Amp, it isn't necessary to manually convert data to half.
        # if args.fp16:
        #     self.mean = self.mean.half()
        #     self.std = self.std.half()
        self.preload()

    def preload(self):
        try:
            self.next_input, self.next_target = next(self.loader)
        except StopIteration:
            self.next_input = None
            self.next_target = None
            return
        # if record_stream() doesn't work, another option is to make sure device inputs are created
        # on the main stream.
        # self.next_input_gpu = torch.empty_like(self.next_input, device='cuda')
        # self.next_target_gpu = torch.empty_like(self.next_target, device='cuda')
        # Need to make sure the memory allocated for next_* is not still in use by the main stream
        # at the time we start copying to next_*:
        # self.stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(self.stream):
            self.next_input = self.next_input.cuda(non_blocking=True)
            self.next_target = self.next_target.cuda(non_blocking=True)
            # more code for the alternative if record_stream() doesn't work:
            # copy_ will record the use of the pinned source tensor in this side stream.
            # self.next_input_gpu.copy_(self.next_input, non_blocking=True)
            # self.next_target_gpu.copy_(self.next_target, non_blocking=True)
            # self.next_input = self.next_input_gpu
            # self.next_target = self.next_target_gpu

            # With Amp, it isn't necessary to manually convert data to half.
            # if args.fp16:
            #     self.next_input = self.next_input.half()
            # else:
            self.next_input = self.next_input.float()
            self.next_input = self.next_input.sub_(self.mean).div_(self.std)

    def next(self):
        torch.cuda.current_stream().wait_stream(self.stream)
        input = self.next_input
        target = self.next_target
        if input is not None:
            input.record_stream(torch.cuda.current_stream())
        if target is not None:
            target.record_stream(torch.cuda.current_stream())
        self.preload()
        return input, target


class ImageDatasetTest(Dataset):
    def __init__(self, query_list_file, query_path, gallery_path, transform):
        self.files = []
        self.imgs = []
        with open(query_list_file, 'r') as file:
            for line in file.readlines():
                name, id_i = line.strip().split()
                name = name.split('/')[-1]
                self.files.append(name)
                name = os.path.join(query_path, name)
                self.imgs.append(name)
        self.query_len = len(self.imgs)

        for file in os.listdir(gallery_path):
            self.files.append(file)
            file = os.path.join(gallery_path, file)
            self.imgs.append(file)

        self.imgs = [read_image(file) for file in self.imgs]
        self.transform = transform

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, item):
        img_item = self.imgs[item]
        img_item = self.transform(img_item)

        return img_item, 1








