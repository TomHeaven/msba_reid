# author = xy
# encoding = utf-8

import json
from data_pre import data_prefetcher
import torch
import numpy as np
import torch.nn.functional as F


def compute_dist_euc(qf, gf):
    m, n = qf.size(0), gf.size(0)
    distmat = torch.pow(qf, 2).sum(dim=1, keepdim=True).expand(m, n) + \
              torch.pow(gf, 2).sum(dim=1, keepdim=True).expand(n, m).t()
    distmat.addmm_(1, -2, qf, gf.t())
    distmat = distmat.cpu().numpy()

    return distmat


def compute_metric(qf, gf, qf_ids, gf_ids, max_rank=200):
    distmat = compute_dist_euc(qf, gf)
    indices = np.argsort(distmat, axis=1)
    matchs = (gf_ids[indices] == qf_ids[:, np.newaxis]).astype(np.int32)

    all_cmc = []
    all_ap = []
    num_valid = 0
    for i in range(len(matchs)):
        org_cmc = matchs[i]
        if sum(org_cmc) == 0:
            continue
        num_valid += 1

        cmc = org_cmc.cumsum()
        cmc[cmc > 1] = 1
        all_cmc.append(cmc[: max_rank])

        num_rel = org_cmc.sum()
        tmp_cmc = org_cmc.cumsum()
        tmp_cmc = [x / (i + 1.0) for i, x in enumerate(tmp_cmc)]
        tmp_cmc = np.asarray(tmp_cmc) * org_cmc
        ap = tmp_cmc.sum() / num_rel
        all_ap.append(ap)

    all_cmc = np.asarray(all_cmc).astype(np.float32)
    all_cmc = all_cmc.sum(0) / num_valid
    map_value = np.mean(all_ap)

    return all_cmc, map_value


def eval_model(model, val_dataloader, query_num, cfg):
    model.eval()
    feats = []
    ids = []
    val_prefetcher = data_prefetcher(val_dataloader)
    batch = val_prefetcher.next()
    while batch[0] is not None:
        with torch.no_grad():
            feat = model(batch)
        feats.append(feat)
        ids.extend(batch[1].cpu().numpy())
        batch = val_prefetcher.next()

    feats = torch.cat(feats, dim=0)
    if cfg.out_norm:
        feats = F.normalize(feats)

    qf = feats[: query_num]
    gf = feats[query_num:]

    qf_ids = np.asarray(ids[: query_num])
    gf_ids = np.asarray(ids[query_num:])

    cmc, Map = compute_metric(qf, gf, qf_ids, gf_ids)

    return cmc, Map


def test_single_model(model, test_dataloader, num_query, files, cfg):
    model.eval()
    feats = []
    test_prefetcher = data_prefetcher(test_dataloader)
    batch = test_prefetcher.next()
    while batch[0] is not None:
        with torch.no_grad():
            feat = model(batch)
        feats.append(feat)
        batch = test_prefetcher.next()

    feats = torch.cat(feats, dim=0)
    if cfg.out_norm:
        feats = F.normalize(feats)

    query_feats = feats[: num_query]
    gallery_feats = feats[num_query:]

    query_files = files[: num_query]
    gallery_files = files[num_query:]

    distmat = torch.mm(query_feats, gallery_feats.t()).cpu().numpy() * -1
    indices = np.argsort(distmat, axis=1)[:, :200]

    result_dict = dict()
    for q_idx in range(num_query):
        query_file = query_files[q_idx]
        gallery_file = [gallery_files[i] for i in indices[q_idx]]
        result_dict[query_file] = gallery_file
        # if q_idx < 10:
        #     print(query_file)
        #     print(gallery_file[:10])
        #     print()

    with open(cfg.submit_file, 'w', encoding='utf-8') as file:
        json.dump(result_dict, file)

    print('data_len:%d' % len(result_dict))









