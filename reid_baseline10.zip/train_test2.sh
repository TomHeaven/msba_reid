sh scripts/train_mgn_resnet50.sh
sh scripts/test_saving_mgn_resnet50.sh



