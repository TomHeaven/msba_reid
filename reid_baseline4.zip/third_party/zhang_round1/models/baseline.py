# author = xy
# encoding = utf-8


import torch
from torch import nn
from torch.nn import functional as F
from models.resnet import ResNet, Bottleneck
from models.triplet_loss import TripletLoss


def weight_init_kaiming(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        nn.init.kaiming_normal_(m.weight, a=0, mode='fan_out')
        nn.init.constant_(m.bias, 0.0)
    elif classname.find('Conv') != -1:
        nn.init.kaiming_normal_(m.weight, a=0, mode='fan_in')
        if m.bias is not None:
            nn.init.constant_(m.bias, 0.0)
    elif classname.find('BatchNorm') != -1:
        if m.affine:
            nn.init.constant_(m.weight, 1.0)
            nn.init.constant_(m.bias, 0.0)


def weight_init_classifier(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        nn.init.normal_(m.weight, std=0.001)
        if m.bias:
            nn.init.constant_(m.bias, 0.0)


class Baseline(nn.Module):
    def __init__(self, pretain_name, num_class, last_stride, margin, model_path):
        super(Baseline, self).__init__()

        self.margin = margin

        if pretain_name == 'resnet50':
            self.base = ResNet(
                last_stride=last_stride,
                block=Bottleneck,
                layers=[3, 4, 6, 3]
            )
        self.base.load_param(model_path)

        self.gap = nn.AdaptiveAvgPool2d(1)
        self.num_class = num_class

        self.bottleneck = nn.BatchNorm1d(2048)
        self.bottleneck.bias.requires_grad_(False)
        self.classifier = nn.Linear(2048, num_class, bias=False)

        self.triplet = TripletLoss(margin)

        self.bottleneck.apply(weight_init_kaiming)
        self.classifier.apply(weight_init_classifier)

    def forward(self, batch):
        x, labels = batch

        global_feat = self.gap(self.base(x))
        global_feat = global_feat.view(-1, global_feat.size()[1])
        feat = self.bottleneck(global_feat)

        if self.training:
            cls_score = self.classifier(feat)
            id_loss = F.cross_entropy(cls_score, labels)
            triplet_loss = self.triplet(global_feat, labels)[0]

            loss = id_loss + triplet_loss
            return loss, [id_loss, triplet_loss]
        else:
            return feat



























