# author = xy
# encoding = utf-8


import numpy as np
import torch
from data_pre import data_prefetcher
from tqdm import tqdm
import json
import torch.nn.functional as F


def re_ranking(probFea, galFea, k1, k2, lambda_value, local_distmat=None, only_local=False):
    # if feature vector is numpy, you should use 'torch.tensor' transform it to tensor
    query_num = probFea.size(0)
    all_num = query_num + galFea.size(0)
    if only_local:
        original_dist = local_distmat
    else:
        feat = torch.cat([probFea,galFea])
        print('using GPU to compute original distance')
        distmat = torch.pow(feat,2).sum(dim=1, keepdim=True).expand(all_num,all_num) + \
                      torch.pow(feat, 2).sum(dim=1, keepdim=True).expand(all_num, all_num).t()
        distmat.addmm_(1,-2,feat,feat.t())
        original_dist = distmat.cpu().numpy()
        del feat
        if not local_distmat is None:
            original_dist = original_dist + local_distmat
    gallery_num = original_dist.shape[0]
    original_dist = np.transpose(original_dist / np.max(original_dist, axis=0))
    V = np.zeros_like(original_dist).astype(np.float16)
    initial_rank = np.argsort(original_dist).astype(np.int32)

    print('starting re_ranking')
    for i in range(all_num):
        # k-reciprocal neighbors
        forward_k_neigh_index = initial_rank[i, :k1 + 1]
        backward_k_neigh_index = initial_rank[forward_k_neigh_index, :k1 + 1]
        fi = np.where(backward_k_neigh_index == i)[0]
        k_reciprocal_index = forward_k_neigh_index[fi]
        k_reciprocal_expansion_index = k_reciprocal_index
        for j in range(len(k_reciprocal_index)):
            candidate = k_reciprocal_index[j]
            candidate_forward_k_neigh_index = initial_rank[candidate, :int(np.around(k1 / 2)) + 1]
            candidate_backward_k_neigh_index = initial_rank[candidate_forward_k_neigh_index,
                                               :int(np.around(k1 / 2)) + 1]
            fi_candidate = np.where(candidate_backward_k_neigh_index == candidate)[0]
            candidate_k_reciprocal_index = candidate_forward_k_neigh_index[fi_candidate]
            if len(np.intersect1d(candidate_k_reciprocal_index, k_reciprocal_index)) > 2 / 3 * len(
                    candidate_k_reciprocal_index):
                k_reciprocal_expansion_index = np.append(k_reciprocal_expansion_index, candidate_k_reciprocal_index)

        k_reciprocal_expansion_index = np.unique(k_reciprocal_expansion_index)
        weight = np.exp(-original_dist[i, k_reciprocal_expansion_index])
        V[i, k_reciprocal_expansion_index] = weight / np.sum(weight)
    original_dist = original_dist[:query_num, ]
    if k2 != 1:
        V_qe = np.zeros_like(V, dtype=np.float16)
        for i in range(all_num):
            V_qe[i, :] = np.mean(V[initial_rank[i, :k2], :], axis=0)
        V = V_qe
        del V_qe
    del initial_rank
    invIndex = []
    for i in range(gallery_num):
        invIndex.append(np.where(V[:, i] != 0)[0])

    jaccard_dist = np.zeros_like(original_dist, dtype=np.float16)

    for i in range(query_num):
        temp_min = np.zeros(shape=[1, gallery_num], dtype=np.float16)
        indNonZero = np.where(V[i, :] != 0)[0]
        indImages = [invIndex[ind] for ind in indNonZero]
        for j in range(len(indNonZero)):
            temp_min[0, indImages[j]] = temp_min[0, indImages[j]] + np.minimum(V[i, indNonZero[j]],
                                                                               V[indImages[j], indNonZero[j]])
        jaccard_dist[i] = 1 - temp_min / (2 - temp_min)

    final_dist = jaccard_dist * (1 - lambda_value) + original_dist * lambda_value
    del original_dist
    del V
    del jaccard_dist
    final_dist = final_dist[:query_num, query_num:]
    return final_dist


def compute_metric_rerank(qf, gf, qf_ids, gf_ids, k1, k2, lambda_value, max_rank=200):
    distmat = re_ranking(qf, gf, k1, k2, lambda_value)
    indices = np.argsort(distmat, axis=1)
    matchs = (gf_ids[indices] == qf_ids[:, np.newaxis]).astype(np.int32)

    all_cmc = []
    all_ap = []
    num_valid = 0
    for i in range(len(matchs)):
        org_cmc = matchs[i]
        if sum(org_cmc) == 0:
            continue
        num_valid += 1

        cmc = org_cmc.cumsum()
        cmc[cmc > 1] = 1
        all_cmc.append(cmc[: max_rank])

        num_rel = org_cmc.sum()
        tmp_cmc = org_cmc.cumsum()
        tmp_cmc = [x / (i + 1.0) for i, x in enumerate(tmp_cmc)]
        tmp_cmc = np.asarray(tmp_cmc) * org_cmc
        ap = tmp_cmc.sum() / num_rel
        all_ap.append(ap)

    all_cmc = np.asarray(all_cmc).astype(np.float32)
    all_cmc = all_cmc.sum(0) / num_valid
    map_value = np.mean(all_ap)

    return all_cmc, map_value


def eval_model_rerank(model, val_dataloader, query_num, cfg):
    model.eval()
    feats = []
    ids = []
    val_prefetcher = data_prefetcher(val_dataloader)
    batch = val_prefetcher.next()
    while batch[0] is not None:
        with torch.no_grad():
            feat = model(batch)
        feats.append(feat)
        ids.extend(batch[1].cpu().numpy())
        batch = val_prefetcher.next()

    feats = torch.cat(feats, dim=0)
    if cfg.out_norm:
        feats = F.normalize(feats)

    qf = feats[: query_num]
    gf = feats[query_num:]

    qf_ids = np.asarray(ids[: query_num])
    gf_ids = np.asarray(ids[query_num:])

    if cfg.find_rerank_param:
        best_cmc = -999
        best_map = -999
        best_result = -999
        best_k1 = -9
        best_k2 = -9
        best_lambda_value = -9
        for k1 in tqdm(cfg.k1s):
            for k2 in cfg.k2s:
                for lambda_value in cfg.lambda_values:
                    cmc, Map = compute_metric_rerank(qf, gf, qf_ids, gf_ids, k1, k2, lambda_value)
                    result = (cmc[0] + Map) / 2
                    if result > best_result:
                        best_cmc = cmc
                        best_map = Map
                        best_result = result
                        best_k1 = k1
                        best_k2 = k2
                        best_lambda_value = lambda_value
                    print('k1:%d, k2:%d, lambda_value:%.2f, r1:%.4f, map:%.4f, result:%.4f' %
                          (k1, k2, lambda_value, cmc[0], Map, result))
        print('best, k1:%d, k2:%d, lambda_value:%.2f, r1:%.4f, map:%.4f, result:%.4f' %
              (best_k1, best_k2, best_lambda_value, best_cmc[0], best_map, best_result))

        return best_cmc, best_map
    else:
        cmc, Map = compute_metric_rerank(qf, gf, qf_ids, gf_ids, cfg.best_k1, cfg.best_k2, cfg.best_lambda_value)
        return cmc, Map


def test_single_model_rerank(model, test_dataloader, num_query, files, cfg):
    model.eval()
    feats = []
    test_prefetcher = data_prefetcher(test_dataloader)
    batch = test_prefetcher.next()
    while batch[0] is not None:
        with torch.no_grad():
            feat = model(batch)
        feats.append(feat)
        batch = test_prefetcher.next()

    feats = torch.cat(feats, dim=0)
    if cfg.out_norm:
        feats = F.normalize(feats)

    query_feats = feats[: num_query]
    gallery_feats = feats[num_query:]

    query_files = files[: num_query]
    gallery_files = files[num_query:]

    distmat = re_ranking(query_feats, gallery_feats, cfg.best_k1, cfg.best_k2, cfg.best_lambda_value)
    indices = np.argsort(distmat, axis=1)[:, :200]

    result_dict = dict()
    for q_idx in range(num_query):
        query_file = query_files[q_idx]
        gallery_file = [gallery_files[i] for i in indices[q_idx]]
        result_dict[query_file] = gallery_file
        # if q_idx < 10:
        #     print(query_file)
        #     print(gallery_file[:10])
        #     print()

    with open(cfg.submit_file, 'w', encoding='utf-8') as file:
        json.dump(result_dict, file)

    print('data_len:%d' % len(result_dict))

