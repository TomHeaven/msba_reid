# author = xy
# encoding = utf-8

from data_pre import build_transform, ImageDatasetTest, fast_collate_fn
from torch.utils.data import DataLoader
import os
import torch
from eval_helper import test_single_model
from re_rank import test_single_model_rerank
from models.baseline import Baseline
from config import Config as cfg


def test_blend(cfg):

    query_list_file = cfg.query_list_file
    query_path = cfg.query_path
    gallery_path = cfg.gallery_path

    transform = build_transform(cfg, is_train=False)
    test_data = ImageDatasetTest(query_list_file, query_path, gallery_path, transform)
    test_loader = DataLoader(test_data, cfg.batch_size, num_workers=cfg.num_workers, collate_fn=fast_collate_fn,
                             pin_memory=True)

    model = Baseline(pretain_name=cfg.pretain_name,
                     num_class=3813,  # 4289
                     last_stride=cfg.last_stride,
                     margin=cfg.margin,
                     model_path=cfg.pretain_path)

    model_path = os.path.join('../models', cfg.version+'.pkl')
    state_dict = torch.load(model_path)
    model.load_state_dict(state_dict)
    model.cuda()
    model.eval()

    if cfg.re_rank:
        test_single_model_rerank(model, test_loader, test_data.query_len, test_data.files, cfg)
    else:
        test_single_model(model, test_loader, test_data.query_len, test_data.files, cfg)


if __name__ == '__main__':
    test_blend(cfg)









