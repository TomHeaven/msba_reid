# author = xy
# encoding = utf-8

import numpy as np


class Config:
    # version
    version = 'baseline_v4'

    # file
    train_data = '../data/train_data.pkl'
    val_data = '../data/val_data.pkl'
    train_path = '../data/初赛训练集/train_set'
    limit_num = 5

    # input
    input_size = [256, 128]
    input_do_flip = True
    input_flip_prob = 0.5
    input_do_pad = True
    input_padding = 10
    input_padding_mode = 'constant'
    input_do_lighting = False
    input_max_lighting = 0.2
    input_do_re = True
    input_re_prob = 0.5

    # dataloader
    epochs = 120  # 50
    num_workers = 8
    batch_size = 32 * 3
    num_instance = 3

    # model
    pretain_name = 'resnet50'
    last_stride = 1
    margin = 0.3
    pretain_path = '../models/pretain/resnet50-19c8e357.pth'

    # optimizer
    lr = 0.00035  # 3e-4
    weight_decay = 0.0005
    bias_lr_factor = 1
    weight_decay_bias = 0.0005  # 0.
    momentum = 0.9
    opt = 'adam'
    steps = (40, 90)  # (30, 50)
    gamma = 0.1
    warmup_factor = 0.01  # 0.1
    warmup_iters = 10
    warmup_method = 'linear'

    # eval
    eval_perid = 10

    # re-rank
    re_rank = True
    find_rerank_param = False
    k1s = [9]  # list(range(1, 20))
    k2s = [2]  # list(range(1, 10))
    lambda_values = list(np.arange(0, 0.5, 0.01))

    best_k1 = 9
    best_k2 = 2
    best_lambda_value = 0.24

    # output
    out_norm = True
    query_list_file = '../data/初赛A榜测试集/query_a_list.txt'
    query_path = '../data/初赛A榜测试集/query_a'
    gallery_path = '../data/初赛A榜测试集/gallery_a'
    submit_file = '../submit/submit.json'

    

