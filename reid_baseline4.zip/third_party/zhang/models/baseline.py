# author = xy
# encoding = utf-8


import torch
from torch import nn
from torch.nn import functional as F
from models.resnet import ResNet, Bottleneck
from models.resnet_ibn import resnet101_ibn_a
from models.resnext_ibn import resnext101_ibn_a
from models.loss_func import TripletLoss, CrossEntropyLabelSmooth, TripletLossAlignedReID


def weight_init_kaiming(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        nn.init.kaiming_normal_(m.weight, a=0, mode='fan_out')
        nn.init.constant_(m.bias, 0.0)
    elif classname.find('Conv') != -1:
        nn.init.kaiming_normal_(m.weight, a=0, mode='fan_in')
        if m.bias is not None:
            nn.init.constant_(m.bias, 0.0)
    elif classname.find('BatchNorm') != -1:
        if m.affine:
            nn.init.constant_(m.weight, 1.0)
            nn.init.constant_(m.bias, 0.0)


def weight_init_classifier(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        nn.init.normal_(m.weight, std=0.001)
        if m.bias:
            nn.init.constant_(m.bias, 0.0)


class HorizontalMaxPool2d(nn.Module):
    def __init__(self):
        super(HorizontalMaxPool2d, self).__init__()

    def forward(self, x):
        inp_size = x.size()
        return F.max_pool2d(input=x, kernel_size=(1, inp_size[3]))


class Baseline(nn.Module):
    def __init__(self, pretain_name, num_class, last_stride, margin, model_path):
        super(Baseline, self).__init__()

        self.margin = margin
        self.pretain_name = pretain_name

        if pretain_name == 'resnet50':
            self.base = ResNet(
                last_stride=last_stride,
                block=Bottleneck,
                layers=[3, 4, 6, 3]
            )

        elif pretain_name == 'resnet101':
            self.base = ResNet(
                last_stride=last_stride,
                block=Bottleneck,
                layers=[3, 4, 23, 3]
            )

        elif pretain_name == 'resnet101_ibn':
            self.base = resnet101_ibn_a(last_stride)

        elif pretain_name == 'resnext101_ibn':
            self.base = resnext101_ibn_a(4, 32, last_stride)

        elif pretain_name in ['resnet101_ibn_aligned_a', 'resnet101_ibn_aligned_b']:
            self.base = resnet101_ibn_a(last_stride)
            self.horizion_pool = HorizontalMaxPool2d()
            self.bn = nn.BatchNorm2d(2048)
            self.relu = nn.ReLU(inplace=True)
            self.conv1 = nn.Conv2d(2048, 128, kernel_size=1, stride=1, padding=0, bias=True)

            self.bn.apply(weight_init_kaiming)
            self.conv1.apply(weight_init_kaiming)

        self.base.load_param(model_path)

        self.gap = nn.AdaptiveAvgPool2d(1)
        self.num_class = num_class

        self.bottleneck = nn.BatchNorm1d(2048)
        self.bottleneck.bias.requires_grad_(False)
        self.classifier = nn.Linear(2048, num_class, bias=False)

        self.ce_loss = nn.CrossEntropyLoss()
        self.triplet = TripletLoss(margin)
        self.triplet_aligned = TripletLossAlignedReID(margin)

        self.bottleneck.apply(weight_init_kaiming)
        self.classifier.apply(weight_init_classifier)

    def forward(self, batch):
        x, labels = batch

        if self.pretain_name in ['resnet50', 'resnet101', 'resnet101_ibn', 'resnext101_ibn']:
            global_feat = self.gap(self.base(x))
            global_feat = global_feat.view(-1, global_feat.size()[1])
            feat = self.bottleneck(global_feat)

            if self.training:
                cls_score = self.classifier(feat)
                id_loss = self.ce_loss(cls_score, labels)
                triplet_loss = self.triplet(global_feat, labels)[0]

                loss = id_loss + triplet_loss
                return loss, [id_loss, triplet_loss]
            else:
                return feat

        elif self.pretain_name in ['resnet101_ibn_aligned_a', 'resnet101_ibn_aligned_b']:
            x = self.base(x)

            if self.training:
                local_feat = self.bn(x)
                local_feat = self.relu(local_feat)
                local_feat = self.horizion_pool(local_feat)
                local_feat = self.conv1(local_feat)
                local_feat = local_feat.view(local_feat.size()[0: 3])
                local_feat = local_feat / torch.pow(local_feat, 2).sum(dim=1, keepdim=True).clamp(min=1e-12).sqrt()

                global_feat = F.avg_pool2d(x, x.size()[2:])
                global_feat = global_feat.view(global_feat.size(0), -1)

                bn_feature = self.bottleneck(global_feat)
                cls_score = self.classifier(bn_feature)
                id_loss = self.ce_loss(cls_score, labels)
                global_triplet_loss, local_triplet_loss = self.triplet_aligned(global_feat, labels, local_feat)

                loss = id_loss + global_triplet_loss + local_triplet_loss
                return loss, [id_loss, global_triplet_loss, local_triplet_loss]
            else:
                # 返回global的bn后，local的bn前
                if self.pretain_name == 'resnet101_ibn_aligned_a':
                    local_feat = self.horizion_pool(x)
                    local_feat = local_feat.view(local_feat.size()[0: 3])
                    local_feat = local_feat / torch.pow(local_feat, 2).sum(dim=1, keepdim=True).clamp(min=1e-12).sqrt()

                    global_feat = F.avg_pool2d(x, x.size()[2:])
                    global_feat = global_feat.view(global_feat.size(0), -1)

                    bn_feature = self.bottleneck(global_feat)

                    return bn_feature, local_feat

                # 返回global的bn前，local的bn后
                elif self.pretain_name == 'resnet101_ibn_aligned_b':
                    local_feat = self.bn(x)
                    local_feat = self.relu(local_feat)
                    local_feat = self.horizion_pool(local_feat)
                    local_feat = self.conv1(local_feat)
                    local_feat = local_feat.view(local_feat.size()[0: 3])
                    local_feat = local_feat / torch.pow(local_feat, 2).sum(dim=1, keepdim=True).clamp(min=1e-12).sqrt()

                    global_feat = F.avg_pool2d(x, x.size()[2:])
                    global_feat = global_feat.view(global_feat.size(0), -1)

                    return global_feat, local_feat



































