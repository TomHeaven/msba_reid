# author = xy
# encoding = utf-8

import numpy as np


class Config:
    # version
    version = 'baseline_v1'

    # file
    data_file = '../data/复赛训练集/train_list.txt'
    train_data = '../data/train_data.pkl'
    val_data = '../data/val_data.pkl'
    train_path = '../data/复赛训练集/train_set'
    limit_num = 2

    # input
    input_size = [256, 128]
    input_do_flip = True
    input_flip_prob = 0.5
    input_do_pad = True
    input_padding = 10
    input_padding_mode = 'constant'
    input_do_lighting = False
    input_max_lighting = 0.2
    input_do_re = True   # 随机擦除
    input_re_prob = 0.5
    input_mean = [41.9800, 53.7991, 62.9194]
    input_std = [34.8325, 35.0004, 46.0474]

    # dataloader
    pretain_name = 'resnet101_ibn'
    bs_dict = {
        'resnet101_ibn': 28,
        'resnext101_ibn': 22
    }
    epochs = 120  # 50
    num_workers = 8
    num_instance = 3
    bs = bs_dict[pretain_name]
    batch_size = bs * num_instance

    # model
    pretain_dict = {
        'resnet50': '../models/pretain/resnet50-19c8e357.pth',
        'resnet101': '../models/pretain/resnet101-5d3b4d8f.pth',
        'resnet101_ibn': '../models/pretain/resnet101_ibn_a.pth.tar',
        'resnet101_ibn_aligned_a': '../models/pretain/resnet101_ibn_a.pth.tar',
        'resnet101_ibn_aligned_b': '../models/pretain/resnet101_ibn_a.pth.tar',
        'resnext101_ibn': '../models/pretain/resnext101_ibn_a.pth.tar',
    }
    last_stride = 1
    margin = 0.3
    pretain_path = pretain_dict[pretain_name]

    # optimizer
    lr = 0.00035  # 3e-4
    weight_decay = 0.0005
    bias_lr_factor = 1
    weight_decay_bias = 0.0005  # 0.
    momentum = 0.9
    opt = 'adam'
    steps = (40, 90)  # (30, 50)
    gamma = 0.1
    warmup_factor = 0.01  # 0.1
    warmup_iters = 10
    warmup_method = 'linear'

    # eval
    eval_perid = 10

    # re-rank
    re_rank = True
    find_rerank_param = False
    k1s = [9]  # list(range(1, 20))
    k2s = [2]  # list(range(1, 10))
    lambda_values = list(np.arange(0, 0.5, 0.01))

    theta = 0.45 if pretain_name == 'resnet101_ibn_aligned_a' else 0.95
    best_k1 = 6
    best_k2 = 2
    best_lambda_value = 0.30

    # output
    out_norm = True
    distmat_save_path = '../submit/tmps/' + version + '_distmat.pkl'
    query_path = '../data/复赛A榜测试集/query_a'
    gallery_path = '../data/复赛A榜测试集/gallery_a'
    submit_file = '../submit/submit.json'

    

