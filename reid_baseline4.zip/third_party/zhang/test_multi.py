# author = xy
# encoding = utf-8

from data_pre import build_transform, ImageDatasetTest, fast_collate_fn
from torch.utils.data import DataLoader
import os
import time
import torch
import pickle
import numpy as np
import json
from eval_helper import test_single_model
from re_rank import test_single_model_rerank_local
from models.baseline import Baseline
from config import Config as cfg


def test_multi(cfg, ensemble_distmats):

    query_path = cfg.query_path
    gallery_path = cfg.gallery_path

    transform = build_transform(cfg, is_train=False)
    test_data = ImageDatasetTest(query_path, gallery_path, transform)

    num_query = test_data.query_len
    files = test_data.files
    query_files = files[: num_query]
    gallery_files = files[num_query:]

    distmat = 0
    for dist_path in ensemble_distmats:
        dist_path = '../submit/tmps/' + dist_path + '_distmat.pkl'
        with open(dist_path, 'rb') as file:
            dist_tmp = pickle.load(file)
            distmat += dist_tmp
    indices = np.argsort(distmat, axis=1)[:, :200]

    result_dict = dict()
    for q_idx in range(num_query):
        query_file = query_files[q_idx]
        gallery_file = [gallery_files[i] for i in indices[q_idx]]
        result_dict[query_file] = gallery_file

    with open(cfg.submit_file, 'w', encoding='utf-8') as file:
        json.dump(result_dict, file)

    print('data_len:%d' % len(result_dict))


if __name__ == '__main__':
    time0 = time.time()
    ensemble_distmats = ['baseline_v12', 'baseline_v12_1', 'baseline_v12_5', 'baseline_v12_6', 'baseline_v12_2']
    test_multi(cfg, ensemble_distmats)
    print('infer_time:%d' % (time.time()-time0))









