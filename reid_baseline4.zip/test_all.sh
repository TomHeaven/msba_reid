sh scripts/test_saving_aligned_resnet101.sh
sh scripts/test_saving_aligned_resnext101.sh
#sh scripts/test_saving_aligned_resnet101_abd.sh



