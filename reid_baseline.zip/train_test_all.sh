#sh scripts/train_aligned_resnet101.sh
#sh scripts/test_saving_aligned_resnet101.sh

sh scripts/train_aligned_resnext101.sh
sh scripts/test_saving_aligned_resnext101.sh

#sh scripts/train_aligned_resnet101_abd.sh
#sh scripts/test_saving_aligned_resnet101_abd.sh

#sh scripts/train_aligned_resnext101_abd.sh
#sh scripts/test_saving_aligned_resnext101_abd.sh

