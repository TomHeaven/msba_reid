# author = xy
# encoding = utf-8


import numpy as np
import pickle
from sklearn.model_selection import StratifiedKFold
from helper import seed_everything


def split_data(data_file, ith, k_folds, limit_num, seed=333):
    seed_everything(seed=seed)

    # 划分训练/验证集，9：1
    id_dict = {}
    with open(data_file, 'r') as file:
        for line in file.readlines():
            name, id_i = line.strip().split()
            name = name.split('/')[-1]
            id_i = int(id_i)
            if id_i in id_dict:
                id_dict[id_i] = id_dict[id_i] + [name]
            else:
                id_dict[id_i] = [name]
    id_num = {}
    for id_i, names in id_dict.items():
        id_num[id_i] = len(names)

    ids = np.asarray(list(id_num.keys()))
    nums = np.asarray(list(id_num.values()))

    splits = list(StratifiedKFold(n_splits=k_folds, shuffle=True).split(ids, nums))
    for kfold, (train_idx, val_idx) in enumerate(splits):
        if kfold == ith:
            train_ids = ids[train_idx]
            val_ids = ids[val_idx]

            r_train_imgs = []
            r_train_ids = []

            r_val_querys = []
            r_val_gallerys = []
            r_val_query_ids = []
            r_val_gallery_ids = []

            for id_i in train_ids:
                names = id_dict[id_i]
                r_train_imgs += names
                r_train_ids += [id_i for _ in range(len(names))]

            for id_i in val_ids:
                names = id_dict[id_i]
                if len(names) < limit_num:
                    continue
                np.random.shuffle(names)

                r_val_querys.append(names.pop(0))
                r_val_query_ids.append(id_i)

                r_val_gallerys += names
                r_val_gallery_ids += [id_i for _ in range(len(names))]

            train_data = {
                'img': r_train_imgs,
                'id': r_train_ids
            }

            val_data = {
                'query': r_val_querys,
                'query_id': r_val_query_ids,
                'gallery': r_val_gallerys,
                'gallery_id': r_val_gallery_ids
            }

            with open('../data/train_data.pkl', 'wb') as file:
                pickle.dump(train_data, file)

            with open('../data/val_data.pkl', 'wb') as file:
                pickle.dump(val_data, file)


if __name__ == '__main__':
    if True:
        data_file = '../data/初赛训练集/train_list.txt'
        split_data(data_file, ith=0, k_folds=5, limit_num=6)




