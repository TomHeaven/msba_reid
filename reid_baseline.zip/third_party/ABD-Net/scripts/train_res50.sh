#!/usr/bin/env bash
export TORCH_HOME=/Users/tomheaven

python3 train.py -s competition1910 -t competition1910 \
    --flip-eval --eval-freq 1 \
    --label-smooth \
    --criterion htri \
    --lambda-htri 0.1  \
    --data-augment crop random-erase \
    --margin 1.2 \
    --train-batch-size 64 \
    --height 384 \
    --width 128 \
    --optim adam --lr 0.0003 \
    --stepsize 20 40 \
    --gpu-devices 0,1 \
    --max-epoch 80 \
    --root /Volumes/Data/比赛/行人重识别2019/data \
    --save-dir /Volumes/Data/比赛/行人重识别2019/ABDNet/weights/resnet50 \
    --arch resnet50 \
    --use-of \
    --abd-dan cam pam \
    --abd-np 2 \
    --shallow-cam \
    --use-ow
