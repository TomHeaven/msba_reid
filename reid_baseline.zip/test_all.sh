
sh scripts/test_saving_aligned_resnet101_sota.sh

sh scripts/test_saving_aligned_resnext101_sota.sh

sh scripts/test_saving_aligned_resnext101_abd_sota.sh

#sh scripts/train_aligned_resnext101_abd.sh
#sh scripts/test_saving_aligned_resnext101_abd.sh

